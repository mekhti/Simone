# DDBridge Driver

### Patches
We can only accept patches which don't break compilation for older kernels (as far back as 2.6.37).

Due to this and other changes not approved by us the kernel version of the ddbridge driver might contain
incompatiblities to this driver package.

### Prepare for Building

   TBD
  
### Building

   TBD
  
  